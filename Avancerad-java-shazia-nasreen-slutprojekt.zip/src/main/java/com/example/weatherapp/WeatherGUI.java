package com.example.weatherapp;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class WeatherGUI {

    private final Stage primaryStage;
    private final WeatherAPI weatherAPI;

    public WeatherGUI(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.weatherAPI = new WeatherAPI();
        initialize();
    }

    public void show() {
        primaryStage.setTitle("Weather App");
        primaryStage.show();
    }

    private void initialize() {
        // Create UI components
        TextField cityTextField = new TextField();
        Button getWeatherButton = new Button("Get Weather");
        Label weatherLabel = new Label();

        // Set up event handling for the button
        getWeatherButton.setOnAction(e -> {
            String city = cityTextField.getText().trim();
            if (!city.isEmpty()) {
                // Call the WeatherAPI class to get weather information
                String weatherInfo = weatherAPI.getWeather(city);

                // Update the UI with the weather information
                weatherLabel.setText(weatherInfo);
            } else {
                weatherLabel.setText("Please enter a city.");
            }
        });

        // Create the layout
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10, 10, 10, 10));
        layout.getChildren().addAll(new Label("Enter City:"), cityTextField, getWeatherButton, weatherLabel);

        // Set up the scene
        Scene scene = new Scene(layout, 300, 200);
        primaryStage.setScene(scene);
    }
}
