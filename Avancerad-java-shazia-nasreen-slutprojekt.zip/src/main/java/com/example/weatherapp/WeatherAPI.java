package com.example.weatherapp;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WeatherAPI {
    private static final String API_KEY = "28ba97e167482e28473b81e71495f78f";
    private static final String API_URL = "https://api.openweathermap.org/data/2.5/weather";

    public String getWeather(String city) {
        try {
            // Construct the URL for the API request
            String apiUrl = String.format("%s?q=%s&appid=%s", API_URL, city, API_KEY);
            URL url = new URL(apiUrl);

            // Open a connection to the URL
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Set the request method
            connection.setRequestMethod("GET");

            // Get the response code
            int responseCode = connection.getResponseCode();

            // Read the response from the API
            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                reader.close();

                // Parse the response as needed (for simplicity, returning the entire response as a string here)
                return response.toString();
            } else {
                return "Error: Unable to fetch weather data. Response Code: " + responseCode;
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "Error: Unable to fetch weather data. Exception: " + e.getMessage();
        }
    }
}
