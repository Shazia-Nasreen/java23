package com.example.weatherapp;

import javafx.application.Application;
import javafx.stage.Stage;

public class WeatherApp extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        WeatherGUI weatherGUI = new WeatherGUI(primaryStage);
        weatherGUI.show();
    }
}
